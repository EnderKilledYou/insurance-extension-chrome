module.exports = {
    publicPath: ''
};